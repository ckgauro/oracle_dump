package com.demo.oracle_dump;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleDumpApplication {

	public static void main(String[] args) {
		SpringApplication.run(OracleDumpApplication.class, args);
	}

}
